create database if not exists rmb;

use rmb;

drop table if exists clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `id_num` bigint DEFAULT NULL,
  `contact` varchar(64) DEFAULT NULL,
  `total_assets` float DEFAULT NULL,
  `monthly_premium` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Doe','John', 1234567899,'0834569325', 50000, 12000);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Public','Mary',9874563215, '0836547896', 75000, 2000);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Queue','Susan',5865478965, '0832541254', 130000, 6500);

INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Williams','David',8856932547, '0836985478', 120000, 3522);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Johnson','Lisa',5565854752, '0835687485', 50000, 4000);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Smith','Paul',5469325874, '0839874563', 100000, 5290);

INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Adams','Carl',9256478548, '0836598754', 50000, 1200);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Brown','Bill',9256854785, '0831254698', 50000, 600);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Thomas','Susan',1236547895, '0838754215', 8000000, 25000);

INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Davis','John',5632584712, '0839632587', 4500000, 6300);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Fowler','Mary',6584789654, '0832587412', 6500000, 6500);
INSERT INTO `clients` (`last_name`,`first_name`,`id_num`, `contact`, `total_assets`, `monthly_premium`) VALUES ('Waters','David',5698742365, '0831593574', 9000000, 1000);
