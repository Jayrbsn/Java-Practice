package rmb;
import java.sql.*;
import java.sql.DriverManager;

public class XMLtoDB {
	
	public static void main(String[] args) {
			
			//NB MUST EDIT CONNECTION VARIABLES FOR YOUR LOCAL ENVIRONMENT
			//Declare argument variables for getConnection method
			String url = "jdbc:mysql://localhost:3306/rmb";
			String user = "student";
			String password = "student";
			
			try {
				
				//Connect to db
				Connection myConn = DriverManager.getConnection(url, user, password);
				System.out.println("Connected to database !");
			}
			catch (Exception exc) {
				exc.printStackTrace();
			}
			
			//Create reader object and call read() method
			XMLReader reader1 = new XMLReader();
			reader1.read();
	}
}
