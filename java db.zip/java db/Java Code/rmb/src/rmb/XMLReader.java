package rmb;
import java.io.File;
import java.sql.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//Youtube video for better breakdown of how to read XML: https://www.youtube.com/watch?v=2JH5YeQ68H8

//Create Class that Reads XML files
public class XMLReader {
	
	//Method to read XMLs
	public void read() {
		
		try {	
			//NB MUST EDIT PATH TO YOUR SPECIFICATIONS
			//Create file to allow us to read xml doc
			File XMLDoc = new File("C:\\Users\\Jarryd\\eclipse-workspace\\rmb\\src\\rmb\\clients.xml");
			
			//Create document builder factory object to enable us to work with DOM
			DocumentBuilderFactory dbFact = DocumentBuilderFactory.newInstance();
			
			//Use the factory to create a builder object
			DocumentBuilder dBuild = dbFact.newDocumentBuilder();
			
			//use document builder to parse the file to xml standards
			org.w3c.dom.Document doc = dBuild.parse(XMLDoc);
			
			//read root element
			//                                     locate doc root        retrieve its name
			System.out.println("root element: " + doc.getDocumentElement().getNodeName());
			
			//read array of student elements
			//this array is called NodeList
			NodeList nList = doc.getElementsByTagName("client");
			
			//NB MUST EDIT CONNECTION VARIABLES FOR YOUR LOCAL ENVIRONMENT
			//Declare arguments to connect to DB 
			String url = "jdbc:mysql://localhost:3306/rmb";
			String user = "student";
			String password = "student";
			
			//Connect to the DB
			Connection myConn = DriverManager.getConnection(url, user, password);
			
			//Create a statement
			Statement myStmt = myConn.createStatement();
			System.out.println("\nAdding client details to database...\n");
			
			//now use for loop to traverse through array
			for (int i=0; i < nList.getLength(); i++) {
				
				Node nNode = nList.item(i);
				
				System.out.println("Node name: " + nNode.getNodeName() + " " +  (i+1));
				
				//only do the below if the node type is an element
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					
					Element eElement = (Element) nNode;
					
					//get elements from XML file and store them in string variables
					String firstName = eElement.getElementsByTagName("firstname").item(0).getTextContent();
					String lastName = eElement.getElementsByTagName("lastname").item(0).getTextContent();
					String ID = eElement.getElementsByTagName("idnum").item(0).getTextContent();
					String contact = eElement.getElementsByTagName("contact").item(0).getTextContent();
					String assets = eElement.getElementsByTagName("assets").item(0).getTextContent();
					String premium = eElement.getElementsByTagName("premium").item(0).getTextContent();
					
					//Insert above variables into DB
					myStmt.executeUpdate("insert into clients " +
					"(first_name, last_name, id_num, contact, total_assets, monthly_premium) " +
							"values " + "('"+firstName+"', '"+lastName+"', '"+ID+"', '"+contact+"', '"+assets+"', '"+premium+"')");
					
					//Display values that are to inserted into db
					System.out.println("Client First Name: " + firstName);
					System.out.println("Client Last Name: " + lastName);
					System.out.println("ID Number : " + ID);
					System.out.println("Contact Num : " + contact);
					System.out.println("Assets with RMB : " + assets);
					System.out.println("Monthly Investment : " + premium);
					System.out.println("--------------------------------------------------------");
					
					
				}
				
				System.out.println("\nDatabase updated !");
			}
		}
		catch (Exception e) {
			System.out.println(e);
			
		}
	}
}
